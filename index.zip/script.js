document.getElementById('add-course').addEventListener('click', () => {
    const inputFields = document.getElementById('input-fields');
    const newInputGroup = document.createElement('div');
    newInputGroup.classList.add('input-group');
    newInputGroup.innerHTML = `
        <input type="text" placeholder="Course Name" class="course-name">
        <input type="text" placeholder="Grade" class="grade">
        <input type="number" placeholder="Credits" class="credits">
    `;
    inputFields.appendChild(newInputGroup);
});

document.getElementById('calculate-cgpa').addEventListener('click', () => {
    const gradeElements = document.querySelectorAll('.grade');
    const creditElements = document.querySelectorAll('.credits');
    let totalCredits = 0;
    let totalGradePoints = 0;

    const gradeToPoint = {
        'A': 4.0, 'A-': 3.7, 'B+': 3.3, 'B': 3.0, 'B-': 2.7,
        'C+': 2.3, 'C': 2.0, 'C-': 1.7, 'D+': 1.3, 'D': 1.0, 'F': 0.0
    };

    gradeElements.forEach((gradeElement, index) => {
        const grade = gradeElement.value.toUpperCase();
        const credits = parseFloat(creditElements[index].value);
        if (grade in gradeToPoint && credits > 0) {
            totalCredits += credits;
            totalGradePoints += gradeToPoint[grade] * credits;
        }
    });

    const cgpa = (totalGradePoints / totalCredits).toFixed(2);
    document.getElementById('result').innerText = `Your CGPA is: ${cgpa}`;
});

document.getElementById('help-button').addEventListener('click', () => {
    document.getElementById('help-modal').style.display = 'flex';
});

document.getElementById('close-button').addEventListener('click', () => {
    document.getElementById('help-modal').style.display = 'none';
});

window.addEventListener('click', (event) => {
    if (event.target == document.getElementById('help-modal')) {
        document.getElementById('help-modal').style.display = 'none';
    }
});
